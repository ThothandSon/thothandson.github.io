"""Khronos — tokens de design.

Aplica a estética Thoth & Son (dark + ouro + serifa) ao customtkinter.
Cores e fontes definidas em um lugar só, para coerência em todos os widgets.
"""

from __future__ import annotations

import customtkinter as ctk

# ── Palette ────────────────────────────────────────────────────
OBSIDIAN = "#0A0A0B"  # base background
SURFACE = "#101012"  # cards / panels
SURFACE_2 = "#16161A"  # hover / depth
GOLD = "#C8A030"  # acento
GOLD_DIM = "#8A6F22"  # acento sutil
GOLD_FAINT = "#3A2E10"  # borda / régua
IVORY = "#F4F1E8"  # texto principal
MUTED_HIGH = "#C8C2B4"  # texto secundário
MUTED_MID = "#9C9586"  # texto terciário
MUTED = "#6E6757"  # microtexto
DANGER = "#C84A3C"
SUCCESS = "#5C8A6A"
WARNING = "#C89030"

# ── Fonts (system fallback chain — sem dependências externas) ──
# macOS já vem com Georgia, Menlo, e Helvetica.
SERIF_FAMILY = "Cormorant SC"  # cai pra system se ausente
SERIF_FALLBACK = "Georgia"
MONO_FAMILY = "IBM Plex Mono"
MONO_FALLBACK = "Menlo"
BODY_FAMILY = "Helvetica Neue"


def _font(family: str, fallback: str, size: int, weight: str = "normal", slant: str = "roman"):
    """Tenta a fonte preferida; cai pro fallback do sistema se não estiver instalada."""
    import tkinter.font as tkfont

    try:
        available = set(tkfont.families())
        chosen = family if family in available else fallback
    except Exception:
        chosen = fallback
    return ctk.CTkFont(family=chosen, size=size, weight=weight, slant=slant)


def serif(size: int, weight: str = "normal"):
    return _font(SERIF_FAMILY, SERIF_FALLBACK, size, weight)


def mono(size: int, weight: str = "normal"):
    return _font(MONO_FAMILY, MONO_FALLBACK, size, weight)


def body(size: int, weight: str = "normal"):
    return _font(BODY_FAMILY, "Helvetica", size, weight)


def italic(size: int):
    return _font(SERIF_FAMILY, SERIF_FALLBACK, size, slant="italic")


# ── Spacing scale ──────────────────────────────────────────────
S1, S2, S3, S4, S5, S6 = 4, 8, 16, 24, 40, 64


def apply_global():
    """Força tema escuro consistente em todo o app."""
    ctk.set_appearance_mode("Dark")
    ctk.set_default_color_theme("dark-blue")  # base; sobrescrevemos cores nos widgets


# ── Helpers de widgets pré-estilizados ──────────────────────────
def gold_button(parent, **kwargs):
    defaults = {
        "fg_color": SURFACE,
        "hover_color": SURFACE_2,
        "border_color": GOLD,
        "border_width": 1,
        "text_color": IVORY,
        "corner_radius": 0,
        "font": mono(11, "bold"),
    }
    defaults.update(kwargs)
    return ctk.CTkButton(parent, **defaults)


def ghost_button(parent, **kwargs):
    defaults = {
        "fg_color": "transparent",
        "hover_color": SURFACE_2,
        "border_color": GOLD_FAINT,
        "border_width": 1,
        "text_color": MUTED_HIGH,
        "corner_radius": 0,
        "font": mono(10),
    }
    defaults.update(kwargs)
    return ctk.CTkButton(parent, **defaults)


def danger_button(parent, **kwargs):
    defaults = {
        "fg_color": "transparent",
        "hover_color": "#2A1614",
        "border_color": DANGER,
        "border_width": 1,
        "text_color": DANGER,
        "corner_radius": 0,
        "font": mono(10, "bold"),
    }
    defaults.update(kwargs)
    return ctk.CTkButton(parent, **defaults)
