<p align="center">
  <img src="assets/khronos-slogan.png" alt="Khronos — o tempo, em ofício." width="720">
</p>

<p align="center">
  <a href="#português">Português</a> · <a href="#english">English</a> · <a href="#español">Español</a>
</p>

<p align="center"><sub>By <a href="https://thothandson.github.io">Thoth & Son</a> · <i>Precisão. Cultura. Resultado.</i></sub></p>

---

<a id="português"></a>

## Português

**Khronos** é um agendador de `cron` nativo para macOS. Vive na barra de menu, abre uma janela enxuta para listar, criar e auditar jobs, e oferece um gerenciador de scripts em pastas dedicadas. Por baixo, é só `cron` — a confiabilidade de cinquenta anos de Unix. Por cima, uma interface sóbria, escura e tipográfica, no padrão da Thoth & Son.

> *O tempo, em ofício.*

### O que faz

- **Visualiza** todos os jobs ativos e pausados em cards densos.
- **Agenda** sem você ter que decorar `* * * * *`: presets em português ("Todo dia à meia-noite") traduzem para sintaxe cron automaticamente.
- **Executa** o comando na hora, em segundo plano, para validação imediata.
- **Mora na menubar** via `rumps`, com ícone que respeita o tema do sistema.
- **Templates dinâmicos**: a pasta `templates/` é uma galeria de comandos prontos (esvaziar lixeira, log de CPU, ping, etc.). Adicione um `.sh` ali e ele aparece no app.
- **Gerenciador de arquivos** com abas separadas para Shell, Python, Logs e Templates.
- **Iniciar com o macOS** via `LaunchAgent` — toggle direto na sidebar.

### Pré-requisitos

- macOS · Python 3.10+ · Tk (`brew install python-tk` se necessário).

### Rodar em desenvolvimento

```bash
git clone https://github.com/ThothandSon/khronos.git
cd khronos
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python menubar.py
```

O ícone aparece na menubar. Clique em **Abrir Khronos** para a janela principal.

#### Modo de teste

```bash
python menubar.py --test
```

Adiciona o preset **"Daqui a 1 minuto (teste)"** para validar comandos sem esperar.

### Gerar o `.app`

```bash
./build_app.sh
```

Bundle gerado em `dist/Khronos.app`. Arraste para **Aplicativos**.

### Estrutura de pastas

```
~/KhronosScripts/
  ├── shell/   # seus shell scripts
  ├── python/  # seus python scripts
  └── logs/    # saídas de execução
```

Se você já tinha um install anterior com `~/CronBuddyScripts/`, o Khronos cria um symlink automático para preservar seus jobs existentes.

---

<a id="english"></a>

## English

**Khronos** is a native `cron` scheduler for macOS. It lives in the menu bar, opens a stripped-down window for listing, creating and auditing jobs, and ships a script manager organized in dedicated folders. Under the hood, it's just `cron` — fifty years of Unix reliability. On top, a sober, dark, typographic UI in the Thoth & Son house style.

> *Time, as craft.*

### What it does

- **Visualize** every active and paused job in dense, calm cards.
- **Schedule** without memorizing `* * * * *`: presets translate to cron syntax for you.
- **Run now** to fire a command in the background — instant validation.
- **Lives in the menubar** via `rumps`, with a template icon that adapts to system theme.
- **Dynamic templates**: drop a `.sh` into `templates/`, it shows up in the app.
- **File manager** with separate tabs for Shell, Python, Logs and Templates.
- **Launch at login** via `LaunchAgent` — single toggle in the sidebar.

### Requirements

- macOS · Python 3.10+ · Tk (`brew install python-tk` if needed).

### Run from source

```bash
git clone https://github.com/ThothandSon/khronos.git
cd khronos
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python menubar.py
```

#### Test mode

```bash
python menubar.py --test
```

### Build `.app`

```bash
./build_app.sh
```

Bundle lands in `dist/Khronos.app`.

---

<a id="español"></a>

## Español

**Khronos** es un programador de `cron` nativo para macOS. Vive en la barra de menú, abre una ventana minimalista para listar, crear y auditar tareas, y trae un gestor de scripts organizado en carpetas dedicadas. Por debajo, es solo `cron` — cincuenta años de confiabilidad Unix. Por encima, una interfaz sobria, oscura y tipográfica, en el estilo de la casa Thoth & Son.

> *El tiempo, como oficio.*

### Qué hace

- **Visualiza** cada tarea activa o pausada en tarjetas densas.
- **Programa** sin memorizar `* * * * *`: presets traducen a sintaxis cron automáticamente.
- **Ejecuta ahora** un comando en segundo plano para validación inmediata.
- **Vive en la barra de menú** vía `rumps`.
- **Templates dinámicos**: ponga un `.sh` en `templates/` y aparece en la app.
- **Gestor de archivos** con pestañas separadas (Shell, Python, Logs, Templates).
- **Iniciar al inicio** vía `LaunchAgent` — toggle directo en la barra lateral.

### Requisitos

- macOS · Python 3.10+ · Tk.

### Ejecutar desde el código

```bash
git clone https://github.com/ThothandSon/khronos.git
cd khronos
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python menubar.py
```

---

## Stack

- **rumps** — agente de menubar nativo.
- **customtkinter** — UI escura/dourada por cima do Tk.
- **python-crontab** — leitura/escrita do crontab do usuário.
- **Pillow** — assets de marca em runtime.
- **py2app** — empacotamento `.app`.

## Licença

MIT — © 2026 Lucas Rafaldini · [Thoth & Son](https://thothandson.github.io).
