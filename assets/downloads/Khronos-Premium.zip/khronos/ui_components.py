"""Khronos — dialogs para criar/editar agendamentos e scripts."""

import datetime
import tkinter.messagebox as messagebox
from typing import Any

import customtkinter as ctk

import theme
from cron_manager import CronManager
from script_manager import ScriptManager
from template_manager import TemplateManager


class JobDialog(ctk.CTkToplevel):
    """Dialog para adicionar ou editar agendamentos cron."""

    def __init__(
        self,
        parent: ctk.CTk,
        cron_manager: CronManager,
        job: dict[str, Any] | None = None,
        title: str = "Novo agendamento",
        is_test_mode: bool = False,
    ) -> None:
        super().__init__(parent)
        self.title(title)
        self.geometry("560x560")
        self.configure(fg_color=theme.OBSIDIAN)
        self.cron_manager = cron_manager
        self.job = job
        self.result = False
        self.is_test_mode = is_test_mode

        ctk.CTkLabel(
            self,
            text=("EDITAR" if job else "NOVO") + " — AGENDAMENTO",
            font=theme.mono(10),
            text_color=theme.GOLD,
        ).pack(pady=(theme.S4, theme.S1), padx=theme.S4, anchor="w")
        ctk.CTkLabel(
            self,
            text=title,
            font=theme.serif(26),
            text_color=theme.IVORY,
        ).pack(pady=(0, theme.S3), padx=theme.S4, anchor="w")

        # Command
        self._field_label("Comando ou script a executar")
        self.template_manager = TemplateManager()
        self.dynamic_templates = self.template_manager.get_templates()

        template_names = ["— escolha um template —", *self.dynamic_templates.keys()]
        self.template_var = ctk.StringVar(value=template_names[0])
        self.template_menu = ctk.CTkOptionMenu(
            self,
            variable=self.template_var,
            command=self.on_template_select,
            values=template_names,
            width=510,
            fg_color=theme.SURFACE,
            button_color=theme.GOLD_FAINT,
            button_hover_color=theme.GOLD_DIM,
            text_color=theme.IVORY,
            font=theme.mono(11),
            corner_radius=0,
        )
        self.template_menu.pack(pady=(0, theme.S1), padx=theme.S4)

        self.command_entry = self._entry()
        self.command_entry.pack(pady=(0, theme.S3), padx=theme.S4)

        # Schedule
        self._field_label("Frequência (* * * * * ou @reboot)")
        presets = [
            "— escolha uma frequência —",
            "A cada minuto",
            "A cada hora",
            "Todo dia à meia-noite",
            "Todo domingo à meia-noite",
            "Todo dia 1 do mês",
            "No boot do sistema",
        ]
        if self.is_test_mode:
            presets.append("Daqui a 1 minuto (teste)")

        self.schedule_preset_var = ctk.StringVar(value=presets[0])
        self.schedule_preset_menu = ctk.CTkOptionMenu(
            self,
            variable=self.schedule_preset_var,
            command=self.on_schedule_select,
            values=presets,
            width=510,
            fg_color=theme.SURFACE,
            button_color=theme.GOLD_FAINT,
            button_hover_color=theme.GOLD_DIM,
            text_color=theme.IVORY,
            font=theme.mono(11),
            corner_radius=0,
        )
        self.schedule_preset_menu.pack(pady=(0, theme.S1), padx=theme.S4)

        self.schedule_entry = self._entry()
        self.schedule_entry.pack(pady=(0, theme.S3), padx=theme.S4)

        # Comment
        self._field_label("Descrição (identificador)")
        self.comment_entry = self._entry()
        self.comment_entry.pack(pady=(0, theme.S3), padx=theme.S4)

        theme.gold_button(
            self,
            text="SALVAR AGENDAMENTO",
            command=self.save,
            height=36,
            width=240,
        ).pack(pady=theme.S4)

        if self.job:
            self.command_entry.insert(0, self.job["command"])
            self.schedule_entry.insert(0, self.job["schedule"])
            self.comment_entry.insert(0, self.job["comment"])

        self.grab_set()

    def _field_label(self, text: str) -> None:
        ctk.CTkLabel(
            self,
            text=text.upper(),
            font=theme.mono(9),
            text_color=theme.GOLD,
        ).pack(pady=(theme.S1, theme.S1), padx=theme.S4, anchor="w")

    def _entry(self):
        return ctk.CTkEntry(
            self,
            width=510,
            height=32,
            fg_color=theme.SURFACE,
            border_color=theme.GOLD_FAINT,
            border_width=1,
            text_color=theme.IVORY,
            font=theme.mono(12),
            corner_radius=0,
        )

    def on_template_select(self, choice: str) -> None:
        if choice in self.dynamic_templates:
            self.command_entry.delete(0, "end")
            self.command_entry.insert(0, self.dynamic_templates[choice])
            self.template_var.set("— escolha um template —")

    def on_schedule_select(self, choice: str) -> None:
        schedules = {
            "A cada minuto": "* * * * *",
            "A cada hora": "0 * * * *",
            "Todo dia à meia-noite": "0 0 * * *",
            "Todo domingo à meia-noite": "0 0 * * 0",
            "Todo dia 1 do mês": "0 0 1 * *",
            "No boot do sistema": "@reboot",
        }
        if choice == "Daqui a 1 minuto (teste)":
            dt = datetime.datetime.now() + datetime.timedelta(minutes=1)
            cron_str = f"{dt.minute} {dt.hour} {dt.day} {dt.month} *"
            self.schedule_entry.delete(0, "end")
            self.schedule_entry.insert(0, cron_str)
            self.schedule_preset_var.set("— escolha uma frequência —")
        elif choice in schedules:
            self.schedule_entry.delete(0, "end")
            self.schedule_entry.insert(0, schedules[choice])
            self.schedule_preset_var.set("— escolha uma frequência —")

    def save(self) -> None:
        command = self.command_entry.get().strip()
        schedule = self.schedule_entry.get().strip()
        comment = self.comment_entry.get().strip()

        if not command or not schedule:
            messagebox.showerror("Faltam dados", "Comando e frequência são obrigatórios.")
            return

        if not self.cron_manager.is_valid_schedule(schedule):
            messagebox.showerror("Inválido", "Frequência cron inválida.")
            return

        if self.job:
            self.cron_manager.edit_job(self.job["comment"], command, schedule, comment)
        else:
            if not comment:
                comment = "Khronos_" + str(hash(command + schedule))
            self.cron_manager.add_job(command, schedule, comment)

        self.result = True
        self.destroy()


class ScriptDialog(ctk.CTkToplevel):
    """Dialog para criar ou editar scripts."""

    def __init__(
        self,
        parent: ctk.CTk,
        script_manager: ScriptManager,
        filename: str = "",
        title: str = "Editor de script",
    ) -> None:
        super().__init__(parent)
        self.title(title)
        self.geometry("660x560")
        self.configure(fg_color=theme.OBSIDIAN)
        self.script_manager = script_manager
        self.filename = filename
        self.result = False

        ctk.CTkLabel(
            self,
            text=("EDITAR" if filename else "NOVO") + " — ARQUIVO",
            font=theme.mono(10),
            text_color=theme.GOLD,
        ).pack(pady=(theme.S4, theme.S1), padx=theme.S4, anchor="w")
        ctk.CTkLabel(
            self,
            text=title,
            font=theme.serif(26),
            text_color=theme.IVORY,
        ).pack(pady=(0, theme.S3), padx=theme.S4, anchor="w")

        ctk.CTkLabel(
            self,
            text="NOME DO ARQUIVO (ex.: backup.sh)",
            font=theme.mono(9),
            text_color=theme.GOLD,
        ).pack(pady=(0, theme.S1), padx=theme.S4, anchor="w")

        self.filename_entry = ctk.CTkEntry(
            self,
            width=610,
            height=32,
            fg_color=theme.SURFACE,
            border_color=theme.GOLD_FAINT,
            border_width=1,
            text_color=theme.IVORY,
            font=theme.mono(12),
            corner_radius=0,
        )
        self.filename_entry.pack(pady=(0, theme.S3), padx=theme.S4)

        ctk.CTkLabel(
            self,
            text="CONTEÚDO",
            font=theme.mono(9),
            text_color=theme.GOLD,
        ).pack(pady=(0, theme.S1), padx=theme.S4, anchor="w")

        self.content_text = ctk.CTkTextbox(
            self,
            width=610,
            height=320,
            fg_color=theme.SURFACE,
            border_color=theme.GOLD_FAINT,
            border_width=1,
            text_color=theme.IVORY,
            font=theme.mono(12),
            corner_radius=0,
        )
        self.content_text.pack(pady=(0, theme.S3), padx=theme.S4)

        theme.gold_button(
            self,
            text="SALVAR SCRIPT",
            command=self.save,
            height=36,
            width=240,
        ).pack(pady=theme.S2)

        if self.filename:
            self.filename_entry.insert(0, self.filename)
            self.filename_entry.configure(state="disabled")
            content = self.script_manager.get_script_content(self.filename)
            self.content_text.insert("1.0", content)

        self.grab_set()

    def save(self) -> None:
        filename = self.filename_entry.get().strip()
        content = self.content_text.get("1.0", "end-1c")

        if not filename:
            messagebox.showerror("Faltam dados", "Nome do arquivo é obrigatório.")
            return

        try:
            filepath = self.script_manager.create_or_edit_script(filename, content)
            messagebox.showinfo("Salvo", f"Script salvo e tornado executável em:\n{filepath}")
            self.result = True
            self.destroy()
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao salvar:\n{e}")
