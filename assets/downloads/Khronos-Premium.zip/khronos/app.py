"""Khronos — janela principal.

Visualização de cron jobs em cards, gerenciador de arquivos (scripts,
templates, logs) e integração com o LaunchAgent do macOS.
"""

import os
import plistlib
import subprocess
import sys
import tkinter as tk
import tkinter.messagebox as messagebox
from typing import Any

import customtkinter as ctk
from PIL import Image

import theme
from cron_manager import CronManager
from logger import logger
from script_manager import ScriptManager
from ui_components import JobDialog, ScriptDialog

theme.apply_global()

# ── Bundle identity ─────────────────────────────────────────────
BUNDLE_ID = "com.thothandson.khronos"
LAUNCH_AGENT_PATH = os.path.expanduser(f"~/Library/LaunchAgents/{BUNDLE_ID}.plist")
LEGACY_LAUNCH_AGENT = os.path.expanduser(
    "~/Library/LaunchAgents/com.lucasrafaldini.cronbuddy.plist"
)

# ── Scripts directory (backward-compatible with old CronBuddy installs) ──
SCRIPTS_DIR = os.path.expanduser("~/KhronosScripts")
LEGACY_SCRIPTS_DIR = os.path.expanduser("~/CronBuddyScripts")


def ensure_scripts_dir() -> str:
    """Ensure ~/KhronosScripts exists; symlink to legacy dir if user already has CronBuddy jobs."""
    if os.path.exists(SCRIPTS_DIR):
        return SCRIPTS_DIR
    if os.path.exists(LEGACY_SCRIPTS_DIR):
        # preserve existing cron jobs that reference the old path
        try:
            os.symlink(LEGACY_SCRIPTS_DIR, SCRIPTS_DIR)
            logger.info(f"Symlinked legacy scripts dir {LEGACY_SCRIPTS_DIR} -> {SCRIPTS_DIR}")
            return SCRIPTS_DIR
        except Exception as e:
            logger.error(f"Failed to symlink legacy scripts dir: {e}")
    os.makedirs(SCRIPTS_DIR, exist_ok=True)
    for sub in ("shell", "python", "logs"):
        os.makedirs(os.path.join(SCRIPTS_DIR, sub), exist_ok=True)
    return SCRIPTS_DIR


class KhronosApp(ctk.CTk):
    """The main application window for Khronos."""

    def __init__(self, is_test_mode: bool = False) -> None:
        super().__init__()

        self.is_test_mode = is_test_mode
        self.title("Khronos — o tempo, em ofício")
        self.geometry("980x640")
        self.configure(fg_color=theme.OBSIDIAN)

        # Window icon
        icon_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "assets", "genfavicon-128.png"
        )
        if os.path.exists(icon_path):
            try:
                photo = tk.PhotoImage(file=icon_path)
                self.wm_iconphoto(True, photo)
            except Exception as e:
                logger.error(f"Failed to set window icon: {e}")

        self.cron_manager = CronManager()

        base_script_dir = ensure_scripts_dir()
        self.shell_manager = ScriptManager(scripts_dir=os.path.join(base_script_dir, "shell"))
        self.python_manager = ScriptManager(scripts_dir=os.path.join(base_script_dir, "python"))
        self.log_manager = ScriptManager(scripts_dir=os.path.join(base_script_dir, "logs"))

        template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
        self.template_manager = ScriptManager(scripts_dir=template_dir)

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()

        # Main view — list of jobs
        self.main_view = ctk.CTkScrollableFrame(self, fg_color=theme.OBSIDIAN)
        self.main_view.grid(row=0, column=1, sticky="nsew", padx=theme.S4, pady=theme.S4)

        self.refresh_jobs()

    # ── Sidebar ─────────────────────────────────────────────────
    def _build_sidebar(self) -> None:
        self.sidebar = ctk.CTkFrame(
            self,
            width=240,
            corner_radius=0,
            fg_color=theme.SURFACE,
            border_width=0,
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew")

        # Logo signet
        logo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "assets", "khronos-signet.png"
        )
        if os.path.exists(logo_path):
            try:
                pil_logo = Image.open(logo_path)
                self.logo_image = ctk.CTkImage(
                    light_image=pil_logo, dark_image=pil_logo, size=(96, 96)
                )
                self.logo_img_label = ctk.CTkLabel(self.sidebar, image=self.logo_image, text="")
                self.logo_img_label.pack(pady=(theme.S5, theme.S2), padx=theme.S4)
            except Exception as e:
                logger.error(f"Failed to load sidebar logo: {e}")

        # Wordmark
        self.logo_label = ctk.CTkLabel(
            self.sidebar,
            text="KHRONOS",
            font=theme.serif(22, "bold"),
            text_color=theme.IVORY,
        )
        self.logo_label.pack(pady=(0, theme.S1), padx=theme.S4)

        # Tagline
        self.tag_label = ctk.CTkLabel(
            self.sidebar,
            text="O TEMPO, EM OFÍCIO",
            font=theme.mono(8),
            text_color=theme.GOLD,
        )
        self.tag_label.pack(pady=(0, theme.S5), padx=theme.S4)

        # Divider
        self._divider(self.sidebar)

        # Primary actions
        theme.gold_button(
            self.sidebar,
            text="+ NOVO AGENDAMENTO",
            height=36,
            command=self.add_job,
        ).pack(pady=(theme.S3, theme.S2), padx=theme.S4, fill="x")

        theme.ghost_button(
            self.sidebar,
            text="ARQUIVOS",
            height=32,
            command=self.manage_files,
        ).pack(pady=theme.S1, padx=theme.S4, fill="x")

        theme.ghost_button(
            self.sidebar,
            text="REVERIFICAR",
            height=32,
            command=self.refresh_jobs,
        ).pack(pady=theme.S1, padx=theme.S4, fill="x")

        # Spacer + system actions
        self._divider(self.sidebar, pad_top=theme.S5)

        self.start_at_login_var = ctk.BooleanVar(value=self.is_launch_at_login_enabled())
        self.chk_start_at_login = ctk.CTkCheckBox(
            self.sidebar,
            text="Iniciar com o macOS",
            variable=self.start_at_login_var,
            command=self.toggle_start_at_login,
            font=theme.body(11),
            text_color=theme.MUTED_HIGH,
            fg_color=theme.GOLD,
            hover_color=theme.GOLD_DIM,
            border_color=theme.GOLD_FAINT,
            checkmark_color=theme.OBSIDIAN,
        )
        self.chk_start_at_login.pack(pady=(theme.S3, theme.S2), padx=theme.S4, anchor="w")

        theme.ghost_button(
            self.sidebar,
            text="ABRIR PASTA DE SCRIPTS",
            height=28,
            command=self.open_scripts_folder,
        ).pack(pady=(theme.S2, theme.S3), padx=theme.S4, fill="x")

        # Footer attribution
        self._divider(self.sidebar, pad_top=theme.S5)
        ctk.CTkLabel(
            self.sidebar,
            text="BY THOTH & SON",
            font=theme.mono(8),
            text_color=theme.MUTED,
        ).pack(pady=(theme.S3, theme.S4), padx=theme.S4)

    def _divider(self, parent, pad_top: int = 0) -> None:
        line = ctk.CTkFrame(parent, height=1, fg_color=theme.GOLD_FAINT)
        line.pack(fill="x", padx=theme.S4, pady=(pad_top, 0))

    # ── Job cards ───────────────────────────────────────────────
    def refresh_jobs(self) -> None:
        for widget in self.main_view.winfo_children():
            widget.destroy()

        # Header
        header = ctk.CTkFrame(self.main_view, fg_color="transparent")
        header.pack(fill="x", pady=(0, theme.S3))
        ctk.CTkLabel(
            header,
            text="— AGENDAMENTOS",
            font=theme.mono(10),
            text_color=theme.GOLD,
        ).pack(side="left")

        jobs = self.cron_manager.get_jobs()
        ctk.CTkLabel(
            header,
            text=f"{len(jobs):02d} ATIVOS" if jobs else "NENHUM ATIVO",
            font=theme.mono(10),
            text_color=theme.MUTED,
        ).pack(side="right")

        if not jobs:
            empty = ctk.CTkFrame(self.main_view, fg_color="transparent", height=200)
            empty.pack(fill="x", pady=theme.S5)
            ctk.CTkLabel(
                empty,
                text="Nada agendado.",
                font=theme.serif(22),
                text_color=theme.MUTED_HIGH,
            ).pack(pady=(theme.S5, theme.S2))
            ctk.CTkLabel(
                empty,
                text="O cron espera sua primeira instrução.",
                font=theme.italic(13),
                text_color=theme.MUTED,
            ).pack()
            return

        for i, job in enumerate(jobs, 1):
            self._create_job_card(job, idx=i)

    def _create_job_card(self, job: dict[str, Any], idx: int = 0) -> None:
        frame = ctk.CTkFrame(
            self.main_view,
            fg_color=theme.SURFACE,
            border_color=theme.GOLD_FAINT,
            border_width=1,
            corner_radius=0,
        )
        frame.pack(fill="x", pady=(0, theme.S2), padx=0)

        body_frame = ctk.CTkFrame(frame, fg_color="transparent")
        body_frame.pack(fill="both", expand=True, padx=theme.S4, pady=theme.S3)

        # Header line: index · status · comment · schedule
        header = ctk.CTkFrame(body_frame, fg_color="transparent")
        header.pack(fill="x")

        ctk.CTkLabel(
            header,
            text=f"{idx:02d}",
            font=theme.mono(10),
            text_color=theme.GOLD,
        ).pack(side="left", padx=(0, theme.S3))

        status_text = "● ATIVO" if job["enabled"] else "○ PAUSADO"
        status_color = theme.SUCCESS if job["enabled"] else theme.MUTED
        ctk.CTkLabel(
            header,
            text=status_text,
            text_color=status_color,
            font=theme.mono(9, "bold"),
        ).pack(side="left", padx=(0, theme.S3))

        comment_text = job["comment"] if job["comment"] else "(sem nome)"
        ctk.CTkLabel(
            header,
            text=comment_text,
            font=theme.serif(18),
            text_color=theme.IVORY,
        ).pack(side="left")

        ctk.CTkLabel(
            header,
            text=f" {job['schedule']} ",
            font=theme.mono(11),
            text_color=theme.GOLD,
            fg_color=theme.OBSIDIAN,
            corner_radius=0,
        ).pack(side="right", padx=theme.S1)

        # Command body
        cmd_frame = ctk.CTkFrame(body_frame, fg_color=theme.OBSIDIAN, corner_radius=0)
        cmd_frame.pack(fill="x", pady=(theme.S2, theme.S2))
        ctk.CTkLabel(
            cmd_frame,
            text=job["command"],
            font=theme.mono(11),
            text_color=theme.MUTED_HIGH,
            justify="left",
            anchor="w",
        ).pack(fill="x", padx=theme.S3, pady=theme.S2)

        # Actions
        actions = ctk.CTkFrame(body_frame, fg_color="transparent")
        actions.pack(fill="x")

        theme.danger_button(
            actions,
            text="EXCLUIR",
            width=84,
            height=28,
            command=lambda c=job["comment"]: self.delete_job(c),
        ).pack(side="right", padx=(theme.S1, 0))

        theme.ghost_button(
            actions,
            text="EDITAR",
            width=70,
            height=28,
            command=lambda j=job: self.edit_job(j),
        ).pack(side="right", padx=theme.S1)

        toggle_text = "PAUSAR" if job["enabled"] else "RETOMAR"
        theme.ghost_button(
            actions,
            text=toggle_text,
            width=80,
            height=28,
            command=lambda j=job: self.toggle_job(j),
        ).pack(side="right", padx=theme.S1)

        theme.gold_button(
            actions,
            text="▶ EXECUTAR AGORA",
            width=160,
            height=28,
            command=lambda j=job: self.run_job_now(j),
        ).pack(side="right", padx=theme.S1)

    # ── Actions ─────────────────────────────────────────────────
    def run_job_now(self, job: dict[str, Any]) -> None:
        command = job["command"]
        try:
            subprocess.Popen(command, shell=True)
            messagebox.showinfo("Executado", f"Comando disparado em segundo plano:\n\n{command}")
        except Exception as e:
            logger.error(f"Failed to execute command '{command}' immediately: {e}")
            messagebox.showerror("Erro", f"Falha ao executar:\n{e}")

    def get_app_bundle_path(self) -> str | None:
        exe_path = os.path.abspath(sys.argv[0])
        parts = exe_path.split(os.sep)
        for i, part in enumerate(parts):
            if part.endswith(".app"):
                return os.sep.join(parts[: i + 1])
        return None

    def is_launch_at_login_enabled(self) -> bool:
        return os.path.exists(LAUNCH_AGENT_PATH)

    def toggle_start_at_login(self) -> None:
        enabled = self.start_at_login_var.get()

        # Clean up legacy CronBuddy plist if present
        if os.path.exists(LEGACY_LAUNCH_AGENT):
            try:
                os.remove(LEGACY_LAUNCH_AGENT)
                logger.info("Removed legacy CronBuddy LaunchAgent.")
            except Exception as e:
                logger.warning(f"Could not remove legacy LaunchAgent: {e}")

        if not enabled:
            if os.path.exists(LAUNCH_AGENT_PATH):
                try:
                    os.remove(LAUNCH_AGENT_PATH)
                    logger.info("Removed LaunchAgent plist.")
                except Exception as e:
                    logger.error(f"Failed to remove LaunchAgent: {e}")
                    messagebox.showerror("Erro", f"Falha ao desativar início automático:\n{e}")
            return

        app_path = self.get_app_bundle_path()
        if not app_path:
            messagebox.showinfo(
                "Modo desenvolvimento",
                "Iniciar com o macOS só funciona quando rodando do bundle .app compilado.",
            )
            return

        plist_data = {
            "Label": BUNDLE_ID,
            "ProgramArguments": ["/usr/bin/open", "-a", app_path],
            "RunAtLoad": True,
        }
        try:
            os.makedirs(os.path.dirname(LAUNCH_AGENT_PATH), exist_ok=True)
            with open(LAUNCH_AGENT_PATH, "wb") as f:
                plistlib.dump(plist_data, f)
            logger.info(f"Created LaunchAgent at {LAUNCH_AGENT_PATH}")
        except Exception as e:
            logger.error(f"Failed to create LaunchAgent: {e}")
            messagebox.showerror("Erro", f"Falha ao ativar início automático:\n{e}")

    def add_job(self) -> None:
        dialog = JobDialog(self, self.cron_manager, is_test_mode=self.is_test_mode)
        self.wait_window(dialog)
        if dialog.result:
            self.refresh_jobs()

    def edit_job(self, job: dict[str, Any]) -> None:
        dialog = JobDialog(
            self,
            self.cron_manager,
            job=job,
            title="Editar agendamento",
            is_test_mode=self.is_test_mode,
        )
        self.wait_window(dialog)
        if dialog.result:
            self.refresh_jobs()

    def delete_job(self, comment: str) -> None:
        if messagebox.askyesno("Confirmar", f"Excluir o agendamento '{comment}'?"):
            self.cron_manager.remove_job(comment)
            self.refresh_jobs()

    def toggle_job(self, job: dict[str, Any]) -> None:
        if job["enabled"]:
            self.cron_manager.disable_job(job["comment"])
        else:
            self.cron_manager.enable_job(job["comment"])
        self.refresh_jobs()

    def manage_files(self) -> None:
        window = ctk.CTkToplevel(self)
        window.title("Arquivos — scripts, templates e logs")
        window.geometry("760x540")
        window.configure(fg_color=theme.OBSIDIAN)
        window.grab_set()

        tabview = ctk.CTkTabview(
            window,
            fg_color=theme.SURFACE,
            segmented_button_fg_color=theme.OBSIDIAN,
            segmented_button_selected_color=theme.GOLD,
            segmented_button_selected_hover_color=theme.GOLD_DIM,
            segmented_button_unselected_color=theme.SURFACE,
            text_color=theme.IVORY,
        )
        tabview.pack(fill="both", expand=True, padx=theme.S4, pady=theme.S3)

        tab_shell = tabview.add("Shell")
        tab_python = tabview.add("Python")
        tab_logs = tabview.add("Logs")
        tab_templates = tabview.add("Templates")

        self._build_file_manager_tab(window, tab_shell, self.shell_manager)
        self._build_file_manager_tab(window, tab_python, self.python_manager)
        self._build_file_manager_tab(window, tab_logs, self.log_manager)
        self._build_file_manager_tab(window, tab_templates, self.template_manager)

    def open_scripts_folder(self) -> None:
        scripts_dir = ensure_scripts_dir()
        try:
            subprocess.run(["open", scripts_dir])
        except Exception as e:
            logger.error(f"Failed to open directory in Finder: {e}")

    def _build_file_manager_tab(
        self, window: ctk.CTkToplevel, parent_tab: ctk.CTkFrame, manager: ScriptManager
    ) -> None:
        list_frame = ctk.CTkScrollableFrame(parent_tab, fg_color=theme.OBSIDIAN)
        list_frame.pack(fill="both", expand=True, padx=theme.S2, pady=theme.S2)

        def refresh_scripts() -> None:
            for w in list_frame.winfo_children():
                w.destroy()
            scripts = manager.get_scripts()
            if not scripts:
                ctk.CTkLabel(
                    list_frame,
                    text="Nada por aqui.",
                    font=theme.italic(14),
                    text_color=theme.MUTED,
                ).pack(pady=theme.S4)
                return

            for s in scripts:
                row = ctk.CTkFrame(
                    list_frame,
                    fg_color=theme.SURFACE,
                    border_color=theme.GOLD_FAINT,
                    border_width=1,
                    corner_radius=0,
                )
                row.pack(fill="x", pady=(0, theme.S1))
                ctk.CTkLabel(
                    row,
                    text=s["name"],
                    font=theme.mono(11),
                    text_color=theme.IVORY,
                ).pack(side="left", padx=theme.S3, pady=theme.S2)

                theme.danger_button(
                    row,
                    text="EXCLUIR",
                    width=70,
                    height=24,
                    command=lambda name=s["name"]: delete_script(name),
                ).pack(side="right", padx=(theme.S1, theme.S2), pady=theme.S1)

                theme.ghost_button(
                    row,
                    text="EDITAR",
                    width=60,
                    height=24,
                    command=lambda name=s["name"]: edit_script(name),
                ).pack(side="right", padx=theme.S1, pady=theme.S1)

        def add_script() -> None:
            d = ScriptDialog(window, manager, title="Novo arquivo")
            window.wait_window(d)
            if d.result:
                refresh_scripts()

        def edit_script(name: str) -> None:
            d = ScriptDialog(window, manager, filename=name, title="Editar arquivo")
            window.wait_window(d)
            if d.result:
                refresh_scripts()

        def delete_script(name: str) -> None:
            if messagebox.askyesno("Confirmar", f"Excluir '{name}'?"):
                manager.delete_script(name)
                refresh_scripts()

        theme.gold_button(
            parent_tab,
            text="+ NOVO ARQUIVO",
            command=add_script,
            height=32,
        ).pack(pady=theme.S2)

        refresh_scripts()


if __name__ == "__main__":
    # Launch menubar in background (it has a lock so it won't duplicate)
    menubar_path = os.path.join(os.path.dirname(__file__), "menubar.py")
    try:
        subprocess.Popen([sys.executable, menubar_path])
    except Exception as e:
        logger.error(f"Failed to launch menubar: {e}")

    is_test_mode = "--test" in sys.argv

    app = KhronosApp(is_test_mode=is_test_mode)
    app.mainloop()
