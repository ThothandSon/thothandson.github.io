#!/bin/bash
# Khronos — build .app for macOS (by Thoth & Son)
# Temporarily hides pyproject.toml to avoid py2app discovery conflicts.

set -e

echo "▶ Khronos · iniciando build do .app"

if [ -f "pyproject.toml" ]; then
    echo "  ◦ ocultando pyproject.toml temporariamente"
    mv pyproject.toml pyproject.toml.tmp
fi

echo "  ◦ montando bundle via py2app"
./venv/bin/python setup.py py2app
BUILD_STATUS=$?

if [ -f "pyproject.toml.tmp" ]; then
    echo "  ◦ restaurando pyproject.toml"
    mv pyproject.toml.tmp pyproject.toml
fi

if [ $BUILD_STATUS -eq 0 ]; then
    echo "✓ build ok · dist/Khronos.app"
else
    echo "✗ build falhou · veja os erros acima"
    exit 1
fi
