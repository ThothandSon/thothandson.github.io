# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-05-31

### Inaugural release as **Khronos**, by Thoth & Son.

Khronos é o sucessor espiritual de um agendador de cron pessoal que rodou
em desktop durante meses. Esta versão re-funda o projeto sob a marca
Thoth & Son, com identidade visual, copy e UI inteiramente refeitas.

### Added
- **Identidade visual completa**: signeta ouroboros + serifa "K", marca lockup
  e slogan card alinhados ao sistema de marca Thoth & Son.
- **Tema escuro/ouro** aplicado a todo o `customtkinter` via `theme.py`
  (tokens de cor, fontes e espaçamento centralizados).
- **Copy em português** em todo o app — labels, presets, mensagens.
- **Ícone de menubar template** que respeita o tema do macOS (light/dark).
- **Backward-compat**: se um install anterior tiver `~/CronBuddyScripts/`,
  o Khronos cria um symlink para `~/KhronosScripts/`, preservando jobs.
- **Bundle id** `com.thothandson.khronos`, LaunchAgent atualizado.
- **Trilingual README** (PT / EN / ES) + atribuição Thoth & Son.

### Changed
- Bundle name e display name: `Khronos`.
- Logger name: `khronos`.
- Diretório padrão de scripts: `~/KhronosScripts/`.
- Prefixo de comentário dos jobs criados: `Khronos_`.

### Removed
- Mascote sticker e paleta azul-claro do release anterior.
- Strings de afeto ("Buddy") substituídas por copy sóbria e técnica.
