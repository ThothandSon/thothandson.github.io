"""Khronos — agente de menubar do macOS.

Roda silenciosamente no canto superior da tela, lança o app principal
sob demanda. Por baixo, ainda é um wrapper sobre o sistema cron nativo.
"""

import os
import subprocess
import sys
from typing import Any

import rumps


class KhronosStatusBarApp(rumps.App):
    """The macOS menu bar agent for Khronos."""

    def __init__(self) -> None:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        icon_path = os.path.join(current_dir, "assets", "status_icon_template.png")
        if os.path.exists(icon_path):
            super().__init__("Khronos", icon=icon_path, template=True)
        else:
            super().__init__("◐")
        self.menu = ["Abrir Khronos", "Encerrar Khronos"]

    @rumps.clicked("Abrir Khronos")
    def open_app(self, _: Any) -> None:
        """Launches the main Khronos application."""
        app_path = os.path.join(os.path.dirname(__file__), "app.py")
        cmd = [sys.executable, app_path]
        if "--test" in sys.argv:
            cmd.append("--test")
        subprocess.Popen(cmd)

    @rumps.clicked("Encerrar Khronos")
    def quit_app(self, _: Any) -> None:
        rumps.quit_application()


if __name__ == "__main__":
    import socket

    # Ensure only one menubar instance runs
    lock_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        lock_socket.bind(("127.0.0.1", 19999))
    except OSError:
        print("Menubar is already running.")
        sys.exit(0)

    app = KhronosStatusBarApp()
    app.quit_button = None
    app.run()
