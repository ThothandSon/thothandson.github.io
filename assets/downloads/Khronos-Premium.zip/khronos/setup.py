"""py2app build configuration for Khronos."""

import sys

from setuptools import setup

APP = ["menubar.py"]

if "py2app" in sys.argv:
    DATA_FILES = [
        "templates",
        "app.py",
        "cron_manager.py",
        "script_manager.py",
        "template_manager.py",
        "ui_components.py",
        "logger.py",
        "theme.py",
        "assets",
    ]
    OPTIONS = {
        "argv_emulation": True,
        "plist": {
            "LSUIElement": True,  # background/menubar app
            "CFBundleName": "Khronos",
            "CFBundleDisplayName": "Khronos",
            "CFBundleIdentifier": "com.thothandson.khronos",
            "CFBundleVersion": "1.0.0",
            "CFBundleShortVersionString": "1.0.0",
            "NSHumanReadableCopyright": "© Thoth & Son. MIT License.",
        },
        "packages": ["rumps", "customtkinter", "crontab", "PIL"],
        "iconfile": "assets/app_icon.icns",
    }
    setup_kwargs = {
        "app": APP,
        "data_files": DATA_FILES,
        "options": {"py2app": OPTIONS},
    }
else:
    setup_kwargs = {
        "packages": [],
        "py_modules": [],
    }

setup(**setup_kwargs)
